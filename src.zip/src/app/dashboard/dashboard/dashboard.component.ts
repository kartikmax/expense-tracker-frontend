import { Component } from '@angular/core';

// Angular Material
// import { MatSidenavModule } from '@angular/material/sidenav';
// import { MatListModule } from '@angular/material/list';
// import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';

// Custom Components
import { SummaryCardsComponent } from '../../components/summary-cards/summary-cards.component';
import { ExpenseTableComponent } from '../../components/expense-table/expense-table.component';
import { ChartsComponent } from '../../components/charts/charts.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    // MatSidenavModule,
    // MatListModule,
    // MatButtonModule,
    MatCardModule,

    SummaryCardsComponent,
    ExpenseTableComponent,
    ChartsComponent
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {

  // ✅ Only summary data stays here
  summaryData = {
    totalBalance: 156750,
    monthlyExpense: 48750,
    upcomingBills: 8750,
    savings: 43
  };

}