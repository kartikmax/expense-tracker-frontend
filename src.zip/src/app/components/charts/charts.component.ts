import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgApexchartsModule } from 'ng-apexcharts';



@Component({
  selector: 'app-charts',
  standalone: true,
  imports: [CommonModule, NgApexchartsModule],
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.scss']
})
export class ChartsComponent {

   lineChartOptions:any = {
    series: [
      {
        name: "Expenses",
        data: [1200, 900, 1500, 800, 2000]
      }
    ],
    chart: {
      type: "line",
      height: 300
    },
    xaxis: {
      categories: ["Mon", "Tue", "Wed", "Thu", "Fri"]
    },
    title: {
      text: "Cash Flow"
    }
  };

  // 🥧 Pie Chart
  pieChartOptions: any = {
    series: [40, 30, 20, 10],
    chart: {
      type: "pie",
      height: 300
    },
    labels: ["Food", "Bills", "Travel", "Others"]
  };
}