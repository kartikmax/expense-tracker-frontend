import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ExpenseService {
  private api = 'http://localhost:5000/api/expenses';

  constructor(private http: HttpClient) {}

  getExpenses(category?: string, sort?: string) {
    let params = new HttpParams();

    if (category) params = params.set('category', category);
    if (sort) params = params.set('sort', sort);

    return this.http.get(this.api, { params });
  }

  addExpense(data: any) {
    return this.http.post(this.api, data);
  }
}