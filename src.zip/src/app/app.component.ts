import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

// Material
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    MatSidenavModule,
    MatListModule,
    MatIconModule
  ],
  templateUrl: './app.component.html'
})
export class AppComponent {}